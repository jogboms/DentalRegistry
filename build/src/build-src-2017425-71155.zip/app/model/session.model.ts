export interface SessionModel {
  id: string;
  created: Date;
  complaint: string;
  diagnosis: string;
  treatment: string;
  patient_id: string;
}
