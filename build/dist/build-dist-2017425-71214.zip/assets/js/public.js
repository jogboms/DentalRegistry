;(function($){

	$('.affixate').affixate({'top':30});

})(jQuery)

